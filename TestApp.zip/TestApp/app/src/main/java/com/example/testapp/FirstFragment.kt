package com.example.testapp

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.testapp.databinding.FirstfragmentBinding

class FirstFragment:Fragment(R.layout.firstfragment) {
    private lateinit var binding: FirstfragmentBinding

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding = FirstfragmentBinding.bind(view)

        binding.btnStart.setOnClickListener{
            findNavController().navigate(
                FirstFragmentDirections.actionFirstFragmentToSecondFragment()
            )
        }
    }
}