package com.example.testapp.Data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.testapp.Data.Dao.TestAppDao


@Database(entities = [TestData::class], version = 3)
abstract class TestAppDatabase : RoomDatabase(){
    companion object {
        private var INSTANCE: TestAppDatabase? = null

        fun getInstance(context: Context): TestAppDatabase {
            INSTANCE?.let {
                return it
            }

            val db = Room.databaseBuilder(
                context, TestAppDatabase::class.java, "quiz.db"
            )
                .createFromAsset("quiz.db")
                .fallbackToDestructiveMigration()
                .allowMainThreadQueries()
                .build()

            INSTANCE = db
            return db
        }
    }

    abstract fun getQuestionsDao(): TestAppDao
}