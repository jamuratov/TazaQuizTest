package com.example.testapp

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.example.testapp.Data.Dao.TestAppDao
import com.example.testapp.Data.TestAppDatabase
import com.example.testapp.databinding.SecondfragmentBinding
import kotlinx.coroutines.launch

class SecondFragment : Fragment(R.layout.secondfragment) {
    private lateinit var binding: SecondfragmentBinding

    private lateinit var db: TestAppDatabase
    private lateinit var dao: TestAppDao
    private var currentQuestionId = 1
    private var selectedAnswerId = -1

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding = SecondfragmentBinding.bind(view)

        db = TestAppDatabase.getInstance(requireContext())
        dao = db.getQuestionsDao()

        lifecycleScope.launch {
            dao.getTestById(currentQuestionId)
        }
        binding.btnBack.setOnClickListener {
            findNavController().navigate(
                SecondFragmentDirections.actionSecondFragmentToFirstFragment()
            )
        }
    }
}