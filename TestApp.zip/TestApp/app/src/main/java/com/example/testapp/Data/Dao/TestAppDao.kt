package com.example.testapp.Data.Dao

import androidx.room.Dao
import androidx.room.Query
import com.example.testapp.Data.TestData

@Dao
interface TestAppDao {

    @Query("SELECT * FROM test")
    suspend fun getQuestions(): List<TestData>

    @Query("SELECT * FROM test WHERE id = :testId")
    suspend fun getTestById(testId: Int): TestData

}