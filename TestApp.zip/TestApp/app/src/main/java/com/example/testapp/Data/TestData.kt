package com.example.testapp.Data

import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity(tableName = "test")
data class TestData(
    @PrimaryKey val id: Int,
    val question: String,
    val answer1: String,
    val answer2: String,
    val answer3: String,
    val answer4: String,
    val correctAnswer: String
)
